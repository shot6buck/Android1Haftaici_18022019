package com.serifgungor.takimlarornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button gs,fb,bjk,ts;
    ImageView iv;

    @Override
    public void onClick(View v) {
        // v.getId() -> Tıklanan butonun Referans ID'sini döner
        switch (v.getId()){
            case R.id.btnGalatasaray:
                iv.setImageResource(R.drawable.gs);
                break;
            case R.id.btnFenerbahce:
                iv.setImageResource(R.drawable.fb);
                break;
            case R.id.btnTrabzonspor:
                iv.setImageResource(R.drawable.ts);
                break;
            case R.id.btnBesiktas:
                iv.setImageResource(R.drawable.bjk);
                break;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = findViewById(R.id.ivResim);
        gs = findViewById(R.id.btnGalatasaray);
        fb = findViewById(R.id.btnFenerbahce);
        bjk = findViewById(R.id.btnBesiktas);
        ts = findViewById(R.id.btnTrabzonspor);

        gs.setOnClickListener(this);
        fb.setOnClickListener(this);
        bjk.setOnClickListener(this);
        ts.setOnClickListener(this);




    }
}
