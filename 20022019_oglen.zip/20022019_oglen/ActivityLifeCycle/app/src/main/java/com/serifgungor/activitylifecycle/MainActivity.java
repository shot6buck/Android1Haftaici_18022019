package com.serifgungor.activitylifecycle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Activity sınıfına layout'u bağladık.


        Log.d("LOG_MESAJI", "onCreate metodu çalıştı");


        //Verbose - Olabilecek tüm logları listeler
        //Debug - Geliştirme esnasında log göstermek için
        //Info - Bilgilendirme amaçlı log göstermek için
        //Warning - Uyarı logları göstermek amaçlı
        //Error - Hata logu göstermek için kullanılır.
        //Assert


        //DEBUG - Log.d()
        //INFO - Log.i()
        //WARNİNG - Log.w()
        //INFORMATION - Log.e()
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LOG_MESAJI", "onStart metodu çalıştı");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("LOG_MESAJI", "onStop metodu çalıştı");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LOG_MESAJI", "onDestroy metodu çalıştı");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LOG_MESAJI", "onPause metodu çalıştı");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LOG_MESAJI", "onResume metodu çalıştı");
    }
}
