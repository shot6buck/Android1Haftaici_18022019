package com.serifgungor.loginexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etUsername,etPassword;
    TextView tvMesaj;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // NESNELERİN REFERANS ADRESLERİ ONCREATE'DE YAZILIR.

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btn = findViewById(R.id.btnIslem);
        tvMesaj = findViewById(R.id.tvMesaj);

        //BUTONA TIKLAMA OLAYI
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = etUsername.getText().toString();
                String pass = etPassword.getText().toString();

                if("root".equals(user) && "1234".equals(pass)){
                    tvMesaj.setText("Hoşgeldiniz !");
                }else{
                    tvMesaj.setText("Hatalı giriş");
                }
                
            }
        });




    }
}
