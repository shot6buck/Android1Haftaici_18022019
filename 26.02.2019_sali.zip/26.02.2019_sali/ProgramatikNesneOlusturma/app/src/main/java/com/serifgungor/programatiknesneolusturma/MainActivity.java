package com.serifgungor.programatiknesneolusturma;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayout;
    Button btn;
    EditText et;

    public void nesneOlustur(int sayiAdedi){
        for(int i=0; i<sayiAdedi; i++){
            Button btn = new Button(getApplicationContext());
            btn.setText("Button");
            linearLayout.addView(btn);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et = findViewById(R.id.etSayiAdedi);
        btn = findViewById(R.id.btnUret);
        linearLayout = findViewById(R.id.linearLayout);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nesneOlustur(Integer.parseInt(et.getText().toString()));
            }
        });

    }
}
